import axios from "axios";

const instance= axios.create({
    baseURL:"https://react-my-burger1-3682f-default-rtdb.firebaseio.com/"
});

export default instance;