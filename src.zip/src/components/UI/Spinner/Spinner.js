import React from "react";
import "./Spinner.css";
const spinner=(props)=>(<div className="loader">Loading...</div>);

export default spinner;